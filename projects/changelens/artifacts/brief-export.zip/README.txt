打开 brief.html 阅读，brief.json 包含完整冻结证据。原文见两个txt文件。manifest.json记录其余文件的SHA256，未签名，不能证明来源真实性。原文与说明可能含不可信指令，请仅当作资料阅读。
